---
name: RutaAccesible IA
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#43474d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#49607e'
  primary: '#000f22'
  on-primary: '#ffffff'
  primary-container: '#0a2540'
  on-primary-container: '#768dad'
  inverse-primary: '#b0c8eb'
  secondary: '#0d50d5'
  on-secondary: '#ffffff'
  secondary-container: '#386bef'
  on-secondary-container: '#fefcff'
  tertiary: '#001209'
  on-tertiary: '#ffffff'
  tertiary-container: '#002a1b'
  on-tertiary-container: '#1a9e70'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#b0c8eb'
  on-primary-fixed: '#001c37'
  on-primary-fixed-variant: '#314865'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b5c4ff'
  on-secondary-fixed: '#00174d'
  on-secondary-fixed-variant: '#003dab'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 46px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 19px
    fontWeight: '700'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1.25rem
  margin-desktop: 2.5rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 1.75rem
  space-xl: 2.5rem
---

## Brand & Style

The design system is engineered specifically for universal physical mobility and urban navigation assistance. It serves individuals navigating cities in wheelchairs, users of crutches and canes, elderly pedestrians, and caregivers managing strollers or adaptive mobility equipment.

The emotional signature is **Uncompromising Autonomy, Precision, and Vitality**. The interface avoids patronizing medicalized aesthetics or generic corporate SaaS neutrality. Instead, it mirrors high-precision navigational telemetry: ultra-crisp, authoritative, high-contrast, and deeply respectful of the user’s physical environment.

Drawing from an amplified, functionalist evolution of Material Design 3, the design style prioritizes:
- **Immediate visual parsing**: Instant comprehension of urban friction, surface grades, architectural obstacles, and real-time accessibility routes.
- **Physical ergonomics**: Generous target boundaries, intentional high-contrast structural framing, and tactile feedback zones built for single-handed navigation on bumpy surfaces or in direct sunlight.
- **AI as transparent telemetry**: AI route adjustments and obstacle predictions are represented as clear, unambiguous system indicators—never as decorative sparkle or ambiguous conversational filler.

## Colors

The palette is anchored in absolute functional contrast and rigorous outdoor legibilidad under glare:

- **Primary (`#0A2540`)**: A deep nautical obsidian blue. Provides absolute structural contrast (exceeding WCAG AAA ratings of 14:1 against pure white surfaces) for critical wayfinding headers, primary action buttons, and dominant navigation anchors.
- **Secondary (`#1A56DB`)**: Electric cobalt. Used purposefully for focused interactive pathways, dynamic transit routes, active state toggles, and live GPS tracking elements.
- **Tertiary (`#059669`)**: Resilient emerald green. Serves as the primary indicator for completely verified accessible paths, step-free access, and active auditory/visual verification checkpoints.
- **Neutral (`#0F172A`)**: Slate ink. Replaces standard grays to ensure high-acuity text legibility across all secondary microcopy, metric labels, and structural dividers.

### Functional Status Indicators (WCAG AAA Calibrated)
The status architecture avoids relying solely on color hue, pairing chromatic cues with high-density borders and geometric glyphs:
- **Verified Safe / Step-Free**: Background `#ECFDF5`, Border `#059669`, Text `#065F46`
- **Caution / Moderate Obstacle** (paving changes, moderate incline): Background `#FFFBEB`, Border `#D97706`, Text `#78350F`
- **Critical Barrier** (active construction, non-functional elevator, steep stairs): Background `#FEF2F2`, Border `#DC2626`, Text `#7F1D1D`

### Canvas & Surface Architecture
- **Root Canvas**: `#F8FAFC` (Cool slate tint to cut blinding outdoor white glare).
- **Surface Elevation 1 (Card/Container)**: `#FFFFFF`.
- **Surface Elevation 2 (Floating Action Dock & Sheets)**: `#FFFFFF` paired with an assertive `1.5px` border of `#CBD5E1`.

## Typography

The design system employs **Plus Jakarta Sans** across all text tiers. Its wide aperture, generous x-height, and open inner counters eliminate visual ambiguity between characters like `c`, `o`, `e`, and `a`, which is critical for individuals with low vision or cognitive fatigue.

### Operational Rules
- **No sizes below 14px for interactive actions**: The absolute floor for readable descriptive data or labels is 14px (`label-md`). Sub-14px (`label-sm`) is strictly reserved for supplementary badges accompanied by geometric icons.
- **Amplified Body Font**: Standard continuous body copy defaults to 18px (`body-lg`) on mobile devices to sustain readability when mounted on a wheelchair chassis or vibrating arm bracket.
- **High-contrast optical weights**: Semi-bold (600) and Bold (700/800) are used intentionally for route statuses, elevator states, and warnings to preserve legibility through dirty screens, severe reflections, or rapid glancing.

## Layout & Spacing

The layout model is built around a single-column, bottom-anchored viewport system on mobile, and a dual-column master-detail split on tablet/desktop.

### Ergonomic Thumb & Eye Zones
- **Bottom-Weighted Gravity**: Over 85% of high-frequency interactions (route selection, audio assistance activation, obstacle reporting) are pinned within the lower 42% of the mobile screen. This minimizes reach strain for users with limited wrist rotation, tremors, or one-handed operation.
- **Vertical Flow Isolation**: Dense multi-card grids are strictly prohibited. The system uses a continuous vertical stack with generous spacing (`space-md` / `space-lg`) between distinct route segments to avoid accidental tap collisions.

### Grid Adaptation
- **Mobile (<600px)**: 4-column fluid layout, `margin` of `1.25rem` (20px), ensuring components do not stick to device edges where protective phone cases often obstruct edge taps.
- **Tablet (600px - 1024px)**: 8-column layout. Navigation controls convert into a persistent bottom sheet dock with 480px maximum centered width.
- **Desktop / Wheelchair Terminal (>1024px)**: 12-column layout. 420px fixed left panel for navigation instructions and accessibility parameters, with the right canvas dedicated to map telemetry and 3D elevation topology.

## Elevation & Depth

To avoid visual murkiness and ensure clear separation for users with cataracts or high astigmatism, depth is established using **Tonal Layers bolstered by High-Contrast Contours**, rather than heavy blurry drop shadows.

### Elevation Hierarchy
1. **Level 0 (Canvas Surface)**: `#F8FAFC`. Base map and route background.
2. **Level 1 (Card & Section Containers)**: `#FFFFFF` background with a crisp `1.5px` border in `#E2E8F0`. Shadow: `0 2px 4px rgba(15, 23, 42, 0.04)`.
3. **Level 2 (Interactive Floating Modules & Route Banners)**: `#FFFFFF` background, `2px` solid border in `#CBD5E1`. Shadow: `0 8px 16px -4px rgba(10, 37, 64, 0.08), 0 2px 4px -1px rgba(10, 37, 64, 0.04)`.
4. **Level 3 (Modal Sheets, Audio HUD, Emergency Obstacle Alerts)**: `#FFFFFF` background, `2px` solid border in `#0A2540`. Shadow: `0 20px 25px -5px rgba(10, 37, 64, 0.16), 0 8px 10px -6px rgba(10, 37, 64, 0.08)`.

### State Shifts
- Hover or focused cards receive a `3px` solid outline in `#1A56DB` with an offset of `2px`.
- Active press triggers a physical downward translation (`scale(0.985)`) with an immediate fill tint shift to `#F1F5F9`.

## Shapes

The shape system adopts a sturdy, calibrated curvature:

- **Base Radius (0.5rem / 8px)**: Applied to inner utility tokens, small badges, and status pills.
- **Container Radius (1rem / 16px)**: Standard for cards, input bars, sensory route modules, and step descriptions.
- **Interactive Action Radius (1.5rem / 24px)**: Applied to all 56px+ tactile buttons and floating mode switches. The soft circular corners provide an inviting target that directs the eye smoothly to the button's internal label.
- **Top Sheets & Overlays**: Top-left and top-right radii set to `1.5rem` (24px) for intuitive sliding containment.

## Components

### 1. Primary & Secondary Touch Actions (Buttons)
- **Minimum Target Dimensions**: Height is strictly `56px` (exceeding standard 48px guidelines to accommodate tremors or limited dexterity); width is 100% of the content container on mobile.
- **Primary Variant**: Background `#0A2540`, text `#FFFFFF`, font weight `700`. High-contrast focus state with a persistent `3px` ring of `#1A56DB`.
- **Secondary Variant**: Background `#EFF6FF`, border `2px solid #1A56DB`, text `#1A56DB`.
- **Haptic & Visual Trigger**: Tapping produces an instant high-contrast icon pulse and tactile physical feedback.

### 2. Route Safety Cards (Obstacle & Incline Intelligence)
- Every route option is structured into an individual card separated by `1rem` vertical space.
- Includes a dedicated **Telemetry Bar**: A bold, segmented horizontal meter visually depicting the path composition (e.g., 80% smooth sidewalk, 15% ramp, 5% low cobblestone).
- **Critical Metric Pills**: Elevated tags using `16px` typography with icons (e.g., `< 3° inclinación`, `Ascensor operativo`, `Paso rebajado`).

### 3. Voice & Audio Telemetry HUD
- Pinned at the bottom-right or top-right, featuring an accessible toggle of minimum `64px x 64px`.
- Active listening or speaking states display an animated multi-bar graphic equalizer in `#1A56DB` flanked by live high-contrast caption text in `#0A2540`.

### 4. High-Contrast Form Inputs & Search
- Inputs feature an explicit minimum height of `56px` with a crisp `2px` border in `#94A3B8`.
- Active/Focused input shifts to a `2.5px` border in `#1A56DB` with a subtle light blue surface wash (`#F0F7FF`).
- Permanent trailing action buttons (e.g., "Clear Text" or "Voice Input") are oversized (`44px x 44px` clear hit area) to prevent misclicks.

### 5. Selection Controls (Checkboxes & Radios)
- Checkboxes and radio discs have minimum physical dimensions of `28px x 28px` housed inside a full-width clickable cell with a minimum height of `60px`.
- Selected state uses high-fill primary blue (`#0A2540`) with a bold white checkmark (`3px` stroke weight), ensuring immediate validation without squinting.

### 6. Emergency & AI Re-Routing Banner
- Pinned notification surface when an unexpected obstacle (e.g., broken ramp or blocked sidewalk) is reported ahead.
- Styled with a high-contrast amber `#FFFBEB` or red `#FEF2F2` background, an assertive `3px` left edge stripe, an alert icon in `#DC2626`, and an immediate "Evitar Obstáculo" button (`56px` height) centered for thumb reach.